package LearnJava;

public class Phone {
	int year;
	String make;
	String model;
	int numberOfCameras;
	//Default Constructor
	Phone(){
		year = 2014;
		make = "Iphone";
		model = "5s";
		numberOfCameras = 2;
		
	}
	Phone(int num, String str1,String str2, int num2){
		year = num;
		make = str1;
		model = str2;
		numberOfCameras = num2;
	}
	
	public String getMake(){
		return make;
	}
	
	public void setMake(String str){
		this.make = str;
	}
	
	public void setModel(String str){
		this.model = str;
		
	}
	public String getModel(){
		return model;
	}
	public void messagePhone(){
		System.out.println("Printing a method in Phone class\n ");
	}
	

}
