package LearnJava;

public class Language {
	int numberOfCountries;
	String languageName;
	String languageOrigin;
	
	//Default Constructor
	Language(){
		numberOfCountries = 2;
		languageName = "Bengali";
		languageOrigin = "Inidan Subcontinent";
		
		
	}
	Language(int num, String str1,String str2){
		numberOfCountries = num;
		languageName = str1;
		languageOrigin = str2;
		
	}
	
	public String getLanguageOrigin(){
		return languageOrigin;
	}
	
	public void setLanguageOrigin(String str){
		this.languageOrigin = str;
	}
	
	public void setLanguageName(String str){
		this.languageName = str;
		
	}
	public String getLanguageName(){
		return languageName;
	}
	public void messageLanguage(){
		System.out.println("Printing a method in Language class\n");
	}
	

}
