package LearnJava;

public class Human {
	int  SSN;
	String name;
	String address;
	int age;
	//Default Constructor
	Human(){
		SSN = 1;
		name = "humanName";
		address = "ABC Street";
		age = 18;
		
	}
	Human(int num, String str1,String str2, int num2){
		SSN = num;
		name = str1;
		address = str2;
		age = num2;
	}
	
	public String getName(){
		return name;
	}
	
	public void setName(String str){
		this.name = str;
	}
	
	public void setAge(int num){
		age = num;
		
	}
	public int getAge(){
		return age;
	}
	public static void messageHuman(){
		System.out.println("This is a Static method in Human class\n");
	}

}
