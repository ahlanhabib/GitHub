package LearnJava;

public class Student {
	int id;
	String name;
	char grade;
	int age;
	//Default Constructor
	Student(){
		id = 1;
		name = "StudentName";
		grade = 'A';
		age = 18;
		
	}
	Student(int num, String str,char grd, int num2){
		id = num;
		name = str;
		grade = grd;
		age = num2;
	}
	
	public String getName(){
		return name;
	}
	
	public void setName(String str){
		this.name = str;
	}
	
	public void setId(int num){
		id = num;
		
	}
	public int getId(){
		return id;
	}
	public static void messageStudent(){
		System.out.println("This is a Static method in Student class\n");
	}
	public static void main(String [] args){
		//Executing objects for Student Class
		Student ob1 = new Student();
		System.out.println(ob1.id+" "+ob1.name+" "+ob1.grade+" "+ob1.age);
		Student ob2 = new Student(2, "Jawad", 'A', 26);
		System.out.println(ob2.id+" "+ob2.name+" "+ob2.grade+" "+ob2.age);
		Student ob3 = new Student();
		ob3.setName("Sharif");
		ob3.setId(3);
		System.out.println(ob3.getId()+" "+ob3.getName());
		messageStudent();
		
		//Executing objects form Vehicle Class
		Vehicle ob4 = new Vehicle();
		System.out.println(ob4.year+" "+ob4.make+" "+ob4.model+" "+ob4.numberOfDoors);
		Vehicle ob5 = new Vehicle(2012, "KIA", "Optima", 4);
		System.out.println(ob5.year+" "+ob5.make+" "+ob5.model+" "+ob5.numberOfDoors);
		Vehicle ob6 = new Vehicle();
		ob6.setMake("BMW");
		ob6.setYear(2016);
		System.out.println(ob6.getYear()+" "+ob6.getMake());
		ob6.messageVehicle();
		
		//Executing objects form Phone Class
		Phone ob7 = new Phone();
		System.out.println(ob7.year+" "+ob7.make+" "+ob7.model+" "+ob7.numberOfCameras);
		Vehicle ob8 = new Vehicle(2006, "Nokia", "1110", 0);
		System.out.println(ob8.year+" "+ob8.make+" "+ob8.model+" "+ob8.numberOfDoors);
		Phone ob9 = new Phone();
		ob9.setMake("Samsung");
		ob9.setModel("GalaxyS");
		System.out.println(ob9.getModel()+" "+ob9.getMake());
		ob9.messagePhone();
		
		//Executing objects form Phone Class
		Human ob10 = new Human();
		System.out.println(ob10.SSN+" "+ob10.name+" "+ob10.address+" "+ob10.age);
		Human ob11 = new Human(792019238, "Jawad", "730 Broaday", 26);
		System.out.println(ob11.SSN+" "+ob11.name+" "+ob11.address+" "+ob11.age);
		Human ob12 = new Human();
		ob12.setName("Sharif");
		ob12.setAge(23);
		System.out.println(ob12.getName()+" "+ob12.getAge());
		ob12.messageHuman();
		
		//Executing objects form Language Class
		Language ob13 = new Language();
		System.out.println(ob13.numberOfCountries+" "+ob13.languageName+" "+ob13.languageOrigin);
		Language ob14 = new Language(1, "Hindi", "India");
		System.out.println(ob14.numberOfCountries+" "+ob14.languageName+" "+ob14.languageOrigin);
		Language ob15 = new Language();
		ob15.setLanguageName("English");
		ob15.setLanguageOrigin("England");
		System.out.println(ob15.getLanguageName()+" "+ob15.getLanguageOrigin());
		ob15.messageLanguage();
		
	}

}
