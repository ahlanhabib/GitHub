package LearnJava;

public class Vehicle {
	int year;
	String make;
	String model;
	int numberOfDoors;
	//Default Constructor
	Vehicle(){
		year = 1990;
		make = "Toyota";
		model = "Avalon";
		numberOfDoors = 4;
		
	}
	Vehicle(int num, String str1,String str2, int num2){
		year = num;
		make = str1;
		model = str2;
		numberOfDoors = num2;
	}
	
	public String getMake(){
		return make;
	}
	
	public void setMake(String str){
		this.make = str;
	}
	
	public void setYear(int num){
		this.year = num;
		
	}
	public int getYear(){
		return year;
	}
	public void messageVehicle(){
		System.out.println("Printing a method in Vehicle class\n");
	}
	
}
